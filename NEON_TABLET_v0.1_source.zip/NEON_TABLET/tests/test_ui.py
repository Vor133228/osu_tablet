import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from PySide6.QtWidgets import QApplication
from ui.main_window import MainWindow
from core.models import Area
app=QApplication.instance() or QApplication([])
def test_pages_and_virtual_device(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    w=MainWindow(simulation=True); w.timer.stop(); w.otd_timer.stop()
    for i in range(4):w.goto(i); assert w.stack.currentIndex()==i
    w.scan_done(w.detector.scan(),None); assert w.device.name=='Wacom CTL-471'; assert w.select.count()==1
    w.editor_change(Area(80,45,76,47.5)); assert w.fields['width'].value()==80
    w.fields['width'].setValue(70); assert w.area.width==70
    w.scan_done([],None); assert w.device is None and not w.apply_btn.isEnabled()
    w.close()

def test_profile_load_and_apply_simulated(tmp_path,monkeypatch):
    from PySide6.QtCore import QEventLoop, QTimer
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    w=MainWindow(simulation=True); w.timer.stop(); w.otd_timer.stop()
    w.scan_done(w.detector.scan(),None)
    w.store.put('Test','Wacom CTL-471',Area(70,40,76,47.5,True)); w.load_profiles()
    idx=next(i for i,p in enumerate(w.profiles_data) if p['name']=='Test'); w.profile_list.setCurrentRow(idx); w.load_profile()
    assert w.active_profile=='Test' and w.area.width==70 and w.dirty
    w.apply()
    loop=QEventLoop(); timer=QTimer(); timer.timeout.connect(lambda: loop.quit() if not w.busy else None); timer.start(10); QTimer.singleShot(3000,loop.quit); loop.exec(); timer.stop()
    assert not w.busy and w.otd.sim_area.width==70 and 'Симуляция' in w.feedback.text()
    w.close()
