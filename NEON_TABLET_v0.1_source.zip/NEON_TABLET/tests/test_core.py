import copy, json
import pytest
from core.device_detector import DeviceDetector
from core.models import Area
from core.storage import ProfileStore
from core.otd_manager import OtdManager, OtdError

def test_ctl471_and_disconnect():
    entries=[{'vendor_id':0x56a,'product_id':0x300,'manufacturer_string':'Wacom','usage_page':13}, {'vendor_id':0x56a,'product_id':0x300,'usage_page':13}]
    det=DeviceDetector(enumerate_fn=lambda:entries)
    devices=det.scan(); assert len(devices)==1
    assert devices[0].name=='Wacom CTL-471' and (devices[0].vid,devices[0].pid)==(0x56a,0x300)
    assert (devices[0].width,devices[0].height)==(152,95)
    entries.clear(); assert det.scan()==[]

def test_unknown_and_non_tablet():
    rows=[{'vendor_id':0x56a,'product_id':0xffff,'usage_page':13},{'vendor_id':4,'product_id':5,'usage_page':1}]
    ds=DeviceDetector(enumerate_fn=lambda: rows).scan(); assert len(ds)==1; assert ds[0].name=='Неизвестное устройство'; assert ds[0].pid==0xffff

def test_profiles(tmp_path):
    store=ProfileStore(tmp_path/'profiles.json'); assert {p['name'] for p in store.all()}=={'Precision','Raw','Smooth'}
    area=Area(70,40,76,47.5,True); store.put('My area','Wacom CTL-471',area)
    assert store.all()[-1]['area']==area.to_dict(); store.rename('My area','Renamed'); assert store.all()[-1]['name']=='Renamed'; store.delete('Renamed'); assert len(store.all())==3

def test_corruption_never_overwritten(tmp_path):
    f=tmp_path/'profiles.json'; f.write_text('{bad'); store=ProfileStore(f)
    with pytest.raises(ValueError):store.all()
    assert f.read_text()=='{bad'

def test_area_bounds():
    Area(100,50,76,47.5).validate(152,95)
    with pytest.raises(ValueError): Area(200,50,76,47).validate(152,95)
    with pytest.raises(ValueError): Area(float('nan'),50,76,47).validate(152,95)

def test_simulation():
    dev=DeviceDetector(True).scan()[0]; otd=OtdManager(simulation=True); area=Area(80,45,76,47.5)
    assert 'Симуляция' in otd.apply(dev,area); assert otd.read(dev)==area

def test_no_otd():
    otd=OtdManager('/definitely/missing/exe'); dev=DeviceDetector(True).scan()[0]
    with pytest.raises(OtdError):otd.read(dev)

class FakeOtd(OtdManager):
    def __init__(self,tmp):
        super().__init__(backup_dir=tmp); self.data={'Profiles':[{'Tablet':'Wacom CTL-471','OutputMode':{'Path':'OpenTabletDriver.Desktop.Output.AbsoluteMode'},'AbsoluteModeSettings':{'Tablet':{'Width':152,'Height':95,'X':76,'Y':47.5,'Rotation':15},'Display':{'Width':1920},'LockAspectRatio':True},'Filters':['keep']}], 'Tools':['keep']}; self.calls=[]
    def snapshot(self): return copy.deepcopy(self.data)
    def run(self,*args):
        self.calls.append(args[0]);
        if args[0]=='load': self.data=json.loads(args[1].read_text())
        return ''

def test_load_apply_preserves_and_verifies(tmp_path):
    otd=FakeOtd(tmp_path); dev=DeviceDetector(True).scan()[0]; area=Area(80,45,76,47.5)
    result=otd.apply(dev,area); assert 'подтверждена' in result; assert otd.read(dev)==area
    assert otd.data['Profiles'][0]['AbsoluteModeSettings']['Tablet']['Rotation']==15
    assert otd.data['Profiles'][0]['Filters']==['keep'] and otd.data['Tools']==['keep']
    assert otd.calls==['load','save-defaults']; assert (tmp_path/'otd-before-last-apply.json').exists()

def test_unsupported_mode(tmp_path):
    otd=FakeOtd(tmp_path); otd.data['Profiles'][0]['OutputMode']['Path']='RelativeMode'
    with pytest.raises(OtdError):otd.apply(DeviceDetector(True).scan()[0],Area(80,45,76,47.5))
    assert not otd.calls

def test_otd_does_not_overwrite_concurrent_changes(tmp_path):
    class Racing(FakeOtd):
        def __init__(self,tmp): super().__init__(tmp); self.count=0
        def snapshot(self):
            self.count+=1
            s=super().snapshot()
            if self.count==2: s['Tools']=['changed externally']
            return s
    otd=Racing(tmp_path)
    with pytest.raises(OtdError,match='изменились'):otd.apply(DeviceDetector(True).scan()[0],Area(80,45,76,47.5))
    assert 'load' not in otd.calls

def test_otd_readback_mismatch(tmp_path):
    class Refusing(FakeOtd):
        def run(self,*args):self.calls.append(args[0]); return ''
    otd=Refusing(tmp_path)
    with pytest.raises(OtdError,match='не подтвердил'):otd.apply(DeviceDetector(True).scan()[0],Area(80,45,76,47.5))
    assert 'save-defaults' not in otd.calls

def test_hid_failure():
    def fail(): raise OSError('access denied')
    with pytest.raises(RuntimeError,match='HID'):DeviceDetector(enumerate_fn=fail).scan()
