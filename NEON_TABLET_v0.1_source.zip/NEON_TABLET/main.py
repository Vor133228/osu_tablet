import argparse, logging, sys
from logging.handlers import RotatingFileHandler
from PySide6.QtWidgets import QApplication, QMessageBox
from core.paths import data_dir
from ui.main_window import MainWindow

def main():
    parser=argparse.ArgumentParser(description='NEON TABLET v0.1'); parser.add_argument('--simulate',action='store_true',help='Виртуальный планшет (без OTD и HID)'); args=parser.parse_args()
    folder=data_dir(); folder.mkdir(parents=True,exist_ok=True)
    handler=RotatingFileHandler(folder/'neon-tablet.log',maxBytes=2_000_000,backupCount=3,encoding='utf-8')
    logging.basicConfig(level=logging.INFO,handlers=[handler],format='%(asctime)s %(levelname)s %(name)s: %(message)s')
    app=QApplication(sys.argv[:1]); app.setApplicationName('NEON TABLET')
    def handle(typ,value,tb):
        logging.critical('Необработанная ошибка',exc_info=(typ,value,tb)); QMessageBox.critical(None,'Ошибка NEON TABLET',f'Произошла ошибка: {value}\nПодробности записаны в журнал.')
    sys.excepthook=handle
    try:
        window=MainWindow(simulation=args.simulate); window.show(); return app.exec()
    except Exception:
        logging.exception('Ошибка запуска'); QMessageBox.critical(None,'Ошибка запуска','Не удалось запустить NEON TABLET. Подробности в журнале.'); return 1
if __name__=='__main__': sys.exit(main())
