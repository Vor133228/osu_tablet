import json, os, tempfile, logging
from pathlib import Path
from .models import Area

log = logging.getLogger(__name__)

def read_json(path, default):
    if not path.exists(): return default
    try:
        with path.open(encoding='utf-8') as f: return json.load(f)
    except (OSError, ValueError) as e:
        log.exception('Ошибка чтения %s', path)
        raise ValueError(f'Не удалось прочитать {path}: {e}. Файл не изменён.') from e

def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    name = None
    try:
        with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent, delete=False, suffix='.tmp') as f:
            name=f.name; json.dump(data, f, ensure_ascii=False, indent=2, allow_nan=False); f.flush(); os.fsync(f.fileno())
        os.replace(name,path)
    finally:
        if name and os.path.exists(name): os.unlink(name)

class ProfileStore:
    def __init__(self, path):
        self.path=Path(path)
        if not self.path.exists():
            self.save_all([
                {'name':'Precision','model':'Wacom CTL-471','area':Area(80,45,76,47.5,True).to_dict()},
                {'name':'Raw','model':'Wacom CTL-471','area':Area(152,95,76,47.5).to_dict()},
                {'name':'Smooth','model':'Wacom CTL-471','area':Area(120,75,76,47.5).to_dict()}])
    def all(self):
        data=read_json(self.path,[])
        if not isinstance(data,list): raise ValueError('Повреждён список профилей. Файл не изменён.')
        for p in data:
            try:
                if not isinstance(p['name'],str) or not p['name'].strip() or not isinstance(p['model'],str): raise ValueError()
                a=Area(**p['area'])
                if not all(isinstance(v,(int,float)) and not isinstance(v,bool) for v in (a.width,a.height,a.x,a.y)) or not isinstance(a.lock,bool): raise ValueError()
                import math
                if not all(math.isfinite(v) for v in (a.width,a.height,a.x,a.y)) or a.width<=0 or a.height<=0: raise ValueError()
            except (KeyError,TypeError,ValueError) as e: raise ValueError('Повреждены данные профиля. Файл не изменён.') from e
        return data
    def save_all(self, items): write_json(self.path, items)
    def put(self, name, model, area, replace=False):
        name=name.strip()
        if not name or len(name)>80: raise ValueError('Имя профиля должно содержать от 1 до 80 символов.')
        items=self.all(); found=next((i for i,p in enumerate(items) if p['name'].casefold()==name.casefold()),None)
        if found is not None and not replace: raise ValueError('Профиль с таким именем уже существует.')
        profile={'name':name,'model':model,'area':area.to_dict()}
        if found is None: items.append(profile)
        else: items[found]=profile
        self.save_all(items)
    def delete(self,name):
        items=self.all(); self.save_all([p for p in items if p['name']!=name])
    def rename(self,old,new):
        items=self.all(); new=new.strip()
        if not new or len(new)>80: raise ValueError('Имя профиля должно содержать от 1 до 80 символов.')
        if any(p['name'].casefold()==new.casefold() and p['name']!=old for p in items): raise ValueError('Профиль с таким именем уже существует.')
        p=next(p for p in items if p['name']==old); p['name']=new; self.save_all(items)
