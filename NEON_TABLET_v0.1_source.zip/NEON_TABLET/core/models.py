from dataclasses import dataclass, asdict
import math

@dataclass
class Area:
    width: float
    height: float
    x: float
    y: float
    lock: bool = False

    def validate(self, physical_width, physical_height):
        values = (self.width, self.height, self.x, self.y, physical_width, physical_height)
        if not all(math.isfinite(v) for v in values):
            raise ValueError('Параметры должны быть конечными числами.')
        if self.width <= 0 or self.height <= 0 or physical_width <= 0 or physical_height <= 0:
            raise ValueError('Размеры должны быть больше нуля.')
        if self.x - self.width / 2 < -0.001 or self.y - self.height / 2 < -0.001 or self.x + self.width / 2 > physical_width + 0.001 or self.y + self.height / 2 > physical_height + 0.001:
            raise ValueError('Область должна целиком находиться внутри планшета.')

    def to_dict(self):
        return asdict(self)

@dataclass
class Device:
    name: str
    manufacturer: str
    vid: int
    pid: int
    width: float | None
    height: float | None
    support: str
    key: str
    simulation: bool = False
