import json, logging
from collections import defaultdict
from .models import Device
from .paths import resource

log=logging.getLogger(__name__)
class DeviceDetector:
    def __init__(self, simulation=False, enumerate_fn=None):
        self.simulation=simulation; self.enumerate_fn=enumerate_fn
        self.db=defaultdict(list)
        for row in json.loads(resource('otd_tablets.json').read_text(encoding='utf8')):
            self.db[(row['vid'],row['pid'])].append(row)
    def scan(self):
        if self.simulation: return [Device('Wacom CTL-471','Wacom',0x056A,0x0300,152,95,'Симуляция: известен OTD','simulation',True)]
        try:
            if self.enumerate_fn is None:
                import hid
                rows=hid.enumerate()
            else: rows=self.enumerate_fn()
        except Exception as e:
            log.exception('Ошибка перечисления HID')
            raise RuntimeError(f'Не удалось прочитать список HID-устройств: {e}') from e
        grouped={}
        for r in rows:
            vid=r.get('vendor_id',0); pid=r.get('product_id',0)
            known=self.db.get((vid,pid),[])
            # Known IDs OR HID digitizer page; no broad guessing by vendor.
            if not known and r.get('usage_page') != 0x0D: continue
            serial=r.get('serial_number') or ''
            key=f'{vid:04x}:{pid:04x}:{serial}'
            names={x['name'] for x in known if x['name']}
            unique=len(names)==1
            row=known[0] if unique else {}
            name=next(iter(names)) if unique else 'Неизвестное устройство'
            support='Есть конфигурация OTD' if unique else ('Неоднозначный VID/PID в базе OTD' if names else 'Не найдена конфигурация OTD')
            grouped[key]=Device(name, str(r.get('manufacturer_string') or row.get('vendor') or 'Неизвестно'),vid,pid,row.get('width'),row.get('height'),support,key)
        return list(grouped.values())
