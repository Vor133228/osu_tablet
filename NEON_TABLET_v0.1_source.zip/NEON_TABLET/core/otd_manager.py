"""OTD 0.6.8.1 console: save / load via daemon. Never starts a daemon."""
import copy, json, logging, os, shutil, subprocess, tempfile
from pathlib import Path
from .models import Area
from .storage import write_json
log=logging.getLogger(__name__)
class OtdError(RuntimeError): pass

class OtdManager:
    def __init__(self, console='', simulation=False, backup_dir=None):
        self.console=console.strip(); self.simulation=simulation; self.backup_dir=backup_dir
        self.sim_area=Area(152,95,76,47.5)
    def find_console(self):
        if self.console:
            return self.console if Path(self.console).is_file() else None
        for n in ('OpenTabletDriver.Console.exe','OpenTabletDriver.Console','otd'):
            if shutil.which(n): return shutil.which(n)
        for root in (os.environ.get('ProgramFiles',''),os.environ.get('LOCALAPPDATA','')):
            if root:
                p=Path(root)/'OpenTabletDriver'/'OpenTabletDriver.Console.exe'
                if p.is_file(): return str(p)
        return None
    def run(self,*args):
        exe=self.find_console()
        if not exe: raise OtdError('Консоль OTD не найдена. Укажите путь в настройках.')
        try:
            r=subprocess.run([exe,*map(str,args)],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=12, creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except (OSError,subprocess.TimeoutExpired) as e: raise OtdError(f'Не удалось запустить консоль OTD: {e}') from e
        text=(r.stdout+'\n'+r.stderr).strip()
        if r.returncode or any(s in text.lower() for s in ('daemon not running','cannot get settings without','invalid settings file','unhandled exception')):
            raise OtdError('Ошибка OTD: '+(text[-1000:] or f'код {r.returncode}'))
        return text
    def snapshot(self):
        with tempfile.TemporaryDirectory(prefix='neon-otd-') as tmp:
            file=Path(tmp)/'settings.json'; self.run('save',file)
            try:
                d=json.loads(file.read_text(encoding='utf-8-sig'))
                if not isinstance(d,dict) or not isinstance(d.get('Profiles'),list): raise ValueError('нет Profiles')
                return d
            except (OSError,ValueError) as e: raise OtdError(f'OTD не вернул корректные настройки. Проверьте демон и версию OTD: {e}') from e
    @staticmethod
    def profile(data,device):
        matches=[p for p in data['Profiles'] if isinstance(p,dict) and p.get('Tablet','').casefold()==device.name.casefold()]
        if len(matches)!=1: raise OtdError('В настройках OTD не найден единственный профиль этой модели. Подключите планшет и настройте его в OTD.')
        p=matches[0]; a=p.get('AbsoluteModeSettings')
        if not isinstance(a,dict) or not isinstance(a.get('Tablet'),dict): raise OtdError('OTD не вернул абсолютную область планшета.')
        return p,a
    def read(self,device):
        if self.simulation: return copy.copy(self.sim_area)
        _,settings=self.profile(self.snapshot(),device); a=settings['Tablet']
        try: return Area(float(a['Width']),float(a['Height']),float(a['X']),float(a['Y']))
        except (ValueError,KeyError,TypeError) as e: raise OtdError('Некорректная область в настройках OTD.') from e
    def apply(self,device,area):
        area.validate(device.width,device.height)
        if self.simulation:
            self.sim_area=copy.copy(area); return 'Симуляция: область изменена только в памяти приложения.'
        if device.name=='Неизвестное устройство': raise OtdError('Применение для неизвестного или неоднозначного устройства запрещено.')
        data=self.snapshot(); profile,absolute=self.profile(data,device)
        mode=profile.get('OutputMode',{}); modepath=mode.get('Path','') if isinstance(mode,dict) else ''
        if not isinstance(modepath,str) or 'absolute' not in modepath.lower():
            raise OtdError('Режим вывода OTD не распознан как абсолютный. Выберите абсолютный режим в OTD.')
        if self.backup_dir:
            try: write_json(Path(self.backup_dir)/'otd-before-last-apply.json',data)
            except OSError as e: raise OtdError(f'Не удалось сохранить резервную копию OTD: {e}') from e
        if self.snapshot() != data:
            raise OtdError('Настройки OTD изменились во время подготовки. Повторите применение, закрыв другие редакторы настроек.')
        for k,v in (('Width',area.width),('Height',area.height),('X',area.x),('Y',area.y)):
            absolute['Tablet'][k]=v
        with tempfile.TemporaryDirectory(prefix='neon-otd-') as tmp:
            file=Path(tmp)/'settings.json'; write_json(file,data); self.run('load',file)
        actual=self.read(device)
        if any(abs(getattr(actual,k)-getattr(area,k)) > 0.01 for k in ('width','height','x','y')):
            raise OtdError('OTD не подтвердил область при повторном чтении. Возможен откат или конфликт с другой программой.')
        # Explicit persistence, then independently check daemon settings again.
        self.run('save-defaults')
        actual=self.read(device)
        if any(abs(getattr(actual,k)-getattr(area,k)) > 0.01 for k in ('width','height','x','y')):
            raise OtdError('Область изменилась после сохранения. Проверьте настройки OTD.')
        return 'Область подтверждена демоном OTD и отправлена на сохранение.'
