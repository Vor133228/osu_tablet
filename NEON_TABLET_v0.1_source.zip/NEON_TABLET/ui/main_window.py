import copy, logging
from functools import partial
from PySide6.QtCore import Qt, QTimer, QObject, Signal, QRunnable, QThreadPool
from PySide6.QtWidgets import (QMainWindow,QWidget,QLabel,QPushButton,QVBoxLayout,QHBoxLayout,QGridLayout,QFrame,QStackedWidget,QScrollArea,QComboBox,QDoubleSpinBox,QCheckBox,QListWidget,QLineEdit,QFileDialog,QMessageBox,QInputDialog,QApplication)
from core.models import Area
from core.storage import read_json,write_json,ProfileStore
from core.device_detector import DeviceDetector
from core.otd_manager import OtdManager
from core.paths import data_dir
from ui.widgets.area_editor import AreaEditor
from ui.style import STYLE
log=logging.getLogger(__name__)

class Signals(QObject):
    done=Signal(object,object)
class Job(QRunnable):
    def __init__(self,fn): super().__init__(); self.fn=fn; self.signals=Signals()
    def run(self):
        try: self.signals.done.emit(self.fn(),None)
        except Exception as e: log.exception('Фоновая операция'); self.signals.done.emit(None,e)

def label(text='',kind=None):
    x=QLabel(text); x.setWordWrap(True)
    if kind: x.setObjectName(kind)
    return x

def card(hero=False):
    f=QFrame(); f.setObjectName('hero' if hero else 'card'); l=QVBoxLayout(f); l.setContentsMargins(20,18,20,18); l.setSpacing(12); return f,l

def btn(text,fn=None,primary=False):
    b=QPushButton(text)
    if primary:b.setObjectName('primary')
    if fn:b.clicked.connect(fn)
    return b

class MainWindow(QMainWindow):
    def __init__(self,simulation=False):
        super().__init__(); self.simulation=simulation; self.base=data_dir(); self.base.mkdir(parents=True,exist_ok=True); self.store=ProfileStore(self.base/'profiles.json')
        try: self.settings=read_json(self.base/'settings.json',{})
        except Exception: log.exception('Настройки'); self.settings={}; QTimer.singleShot(0,lambda:self.error('Файл настроек повреждён. Используются временные значения; исходный файл не изменён.'))
        if not isinstance(self.settings,dict): self.settings={}
        self.detector=DeviceDetector(simulation); self.otd=OtdManager(self.settings.get('otd_console',''),simulation,self.base/'backups'); self.devices=[]; self.first_scan=True; self.device=None; self.active_profile='Не выбран'; self.dirty=False; self.block=False; self.scanning=False; self.busy=False; self.jobs=[]
        self.area=Area(152,95,76,47.5); self.ratio=self.area.width/self.area.height
        self.setWindowTitle('NEON TABLET'+(' — СИМУЛЯЦИЯ' if simulation else '')); self.setMinimumSize(850,600); self.resize(1240,820); self.setStyleSheet(STYLE)
        self.build(); self.load_profiles(); self.timer=QTimer(self); self.timer.timeout.connect(self.scan); self.timer.start(3000); self.otd_timer=QTimer(self); self.otd_timer.timeout.connect(self.poll_otd); self.otd_timer.start(15000); QTimer.singleShot(50,self.scan)
    def error(self,text): QMessageBox.warning(self,'NEON TABLET',str(text))
    def submit(self,fn,callback):
        j=Job(fn); self.jobs.append(j)
        def done(result,err):
            if j in self.jobs:self.jobs.remove(j)
            callback(result,err)
        j.signals.done.connect(done); QThreadPool.globalInstance().start(j)
    def build(self):
        root=QWidget(); root.setObjectName('root'); self.setCentralWidget(root); outer=QHBoxLayout(root); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)
        side=QWidget(); side.setObjectName('sidebar'); side.setFixedWidth(220); sl=QVBoxLayout(side); sl.setContentsMargins(17,25,17,20); sl.setSpacing(5)
        sl.addWidget(label('◈  NEON TABLET','brand')); sl.addWidget(label('CONTROL CENTER  /  v0.1','eyebrow')); sl.addSpacing(28)
        self.stack=QStackedWidget(); self.nav=[]
        for i,(text,build) in enumerate([('⌂   Главная',self.home),('▱   Планшет',self.tablet),('◫   Профили',self.profiles),('⚙   Настройки',self.settings_page)]):
            b=btn(text,partial(self.goto,i)); b.setObjectName('nav'); b.setCheckable(True); sl.addWidget(b); self.nav.append(b)
            page=build(); scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(page); self.stack.addWidget(scroll)
        sl.addSpacing(25); sl.addWidget(label('СКОРО','eyebrow'))
        for t in ('Precision Engine','Плагины','Мониторинг','osu! Integration'):
            x=label('  ·  '+t,'muted'); sl.addWidget(x)
        sl.addStretch(); sl.addWidget(label('●  '+('СИМУЛЯЦИЯ' if self.simulation else 'ЛОКАЛЬНЫЙ РЕЖИМ'),'eyebrow'))
        outer.addWidget(side); outer.addWidget(self.stack,1); self.goto(0)
    def goto(self,i):
        self.stack.setCurrentIndex(i)
        for n,b in enumerate(self.nav): b.setChecked(i==n)
    def page(self,title,subtitle):
        w=QWidget(); w.setObjectName('page'); v=QVBoxLayout(w); v.setContentsMargins(34,30,34,30); v.setSpacing(16); v.addWidget(label('NEON TABLET  /  '+title.upper(),'eyebrow')); v.addWidget(label(title,'title')); v.addWidget(label(subtitle,'subtitle')); return w,v
    def home(self):
        w,v=self.page('Главная','Всё необходимое для настройки вашего планшета.'); h,hv=card(True); hv.addWidget(label('ВАШЕ УСТРОЙСТВО','eyebrow')); self.home_name=label('Поиск планшета…','big'); hv.addWidget(self.home_name); self.home_status=label('Проверяем подключение','status'); hv.addWidget(self.home_status); hv.addSpacing(12); hv.addWidget(btn('Настроить планшет  →',lambda:self.goto(1),True),alignment=Qt.AlignmentFlag.AlignLeft); v.addWidget(h)
        row=QHBoxLayout(); c,cl=card(); cl.addWidget(label('АКТИВНАЯ ОБЛАСТЬ','eyebrow')); self.home_area=label('—','big'); cl.addWidget(self.home_area); cl.addWidget(label('Ширина × высота, мм','muted')); cl.addWidget(btn('Изменить область',lambda:self.goto(1))); row.addWidget(c)
        c,cl=card(); cl.addWidget(label('ПРОФИЛЬ','eyebrow')); self.home_profile=label('Не выбран','big'); cl.addWidget(self.home_profile); cl.addWidget(label('Настройки рабочей области','muted')); cl.addWidget(btn('Открыть профили',lambda:self.goto(2))); row.addWidget(c); v.addLayout(row); v.addStretch(); return w
    def tablet(self):
        w,v=self.page('Планшет','Предпросмотр изменений не влияет на устройство до применения.'); self.sim_banner=label('СИМУЛЯЦИЯ: данные виртуальные, реальный планшет не изменяется.','status'); self.sim_banner.setVisible(self.simulation); v.addWidget(self.sim_banner)
        c,cl=card(); row=QHBoxLayout(); row.addWidget(label('УСТРОЙСТВО','eyebrow')); row.addStretch(); self.select=QComboBox(); self.select.setMinimumWidth(240); self.select.currentIndexChanged.connect(self.choose_device); row.addWidget(self.select); cl.addLayout(row); self.device_info=label('Устройство не подключено','big'); cl.addWidget(self.device_info); self.device_detail=label('VID —  ·  PID —  ·  OTD —','muted'); cl.addWidget(self.device_detail); self.otd_state=label('Демон OTD: состояние не проверено','status'); cl.addWidget(self.otd_state); v.addWidget(c)
        row=QHBoxLayout(); left,ll=card(); ll.addWidget(label('РАБОЧАЯ ОБЛАСТЬ','eyebrow')); ll.addWidget(label('Область планшета','big')); self.editor=AreaEditor(); self.editor.changed.connect(self.editor_change); ll.addWidget(self.editor,1); row.addWidget(left,3)
        right,rl=card(); rl.addWidget(label('ПАРАМЕТРЫ  /  ММ','eyebrow')); grid=QGridLayout(); grid.setHorizontalSpacing(10); self.fields={}
        for idx,(key,text) in enumerate([('width','Ширина'),('height','Высота'),('x','Центр X'),('y','Центр Y'),('offset_x','Смещение X'),('offset_y','Смещение Y')]):
            grid.addWidget(label(text,'muted'),idx//2*2,idx%2); spin=QDoubleSpinBox(); spin.setRange(-10000,10000); spin.setDecimals(2); spin.setSingleStep(.5); spin.valueChanged.connect(partial(self.field_change,key)); self.fields[key]=spin; grid.addWidget(spin,idx//2*2+1,idx%2)
        rl.addLayout(grid); self.lock=QCheckBox('Сохранять пропорции'); self.lock.toggled.connect(self.toggle_lock); rl.addWidget(self.lock); rl.addWidget(label('X / Y — центр области. Смещение — от центра планшета.','muted')); rl.addStretch(); row.addWidget(right,2); v.addLayout(row)
        actions=QHBoxLayout(); self.apply_btn=btn('Применить к OTD',self.apply,True); actions.addWidget(self.apply_btn); actions.addWidget(btn('Сбросить',self.reset)); actions.addWidget(btn('Сохранить профиль',self.save_profile)); actions.addWidget(btn('Прочитать из OTD',self.read_otd)); actions.addStretch(); v.addLayout(actions); self.feedback=label('Изменения ещё не применены.','muted'); v.addWidget(self.feedback); v.addStretch(); self.refresh_fields(); return w
    def profiles(self):
        w,v=self.page('Профили','Сохраняйте и загружайте настройки области. Фильтры не входят в профили v0.1.'); c,cl=card(); self.profile_list=QListWidget(); self.profile_list.currentRowChanged.connect(self.profile_selected); cl.addWidget(self.profile_list); self.profile_desc=label('Выберите профиль','muted'); cl.addWidget(self.profile_desc); v.addWidget(c,1)
        row=QHBoxLayout(); row.addWidget(btn('Загрузить в редактор',self.load_profile,True)); row.addWidget(btn('Создать / сохранить',self.save_profile)); row.addWidget(btn('Переименовать',self.rename_profile)); row.addWidget(btn('Удалить',self.delete_profile)); v.addLayout(row); return w
    def settings_page(self):
        w,v=self.page('Настройки','Интеграция с OpenTabletDriver и локальные данные.'); c,cl=card(); cl.addWidget(label('OPEN TABLET DRIVER','eyebrow')); cl.addWidget(label('Путь к OpenTabletDriver.Console.exe','big')); cl.addWidget(label('Оставьте пустым для автоматического поиска. Демон необходимо запустить отдельно.','muted')); row=QHBoxLayout(); self.console_input=QLineEdit(self.settings.get('otd_console','')); self.console_input.setPlaceholderText('Автоматический поиск'); row.addWidget(self.console_input); row.addWidget(btn('Обзор',self.browse)); cl.addLayout(row); cl.addWidget(btn('Сохранить настройки',self.save_settings),alignment=Qt.AlignmentFlag.AlignLeft); v.addWidget(c)
        c,cl=card(); cl.addWidget(label('ЛОКАЛЬНЫЕ ДАННЫЕ','eyebrow')); cl.addWidget(label(str(self.base),'muted')); cl.addWidget(label('Профили, резервная копия OTD и журнал хранятся отдельно от программы.','muted')); v.addWidget(c); v.addStretch(); return w
    def browse(self):
        p,_=QFileDialog.getOpenFileName(self,'Выберите консоль OTD','','Приложение (*.exe);;Все файлы (*)')
        if p:self.console_input.setText(p)
    def save_settings(self):
        try:
            self.settings['otd_console']=self.console_input.text().strip(); write_json(self.base/'settings.json',self.settings); self.otd.console=self.settings['otd_console']; self.feedback.setText('Путь к OTD сохранён.'); self.scan()
        except Exception as e: self.error(e)
    def scan(self):
        if self.scanning:return
        self.scanning=True
        self.submit(self.detector.scan,self.scan_done)
    def scan_done(self,devices,err):
        self.scanning=False
        if err: self.otd_state.setText('Ошибка HID: '+str(err)); return
        old=self.device.key if self.device else None
        signature=lambda ds:[(d.key,d.name,d.support) for d in ds]
        if signature(devices)==signature(self.devices) and not self.first_scan: return
        self.first_scan=False
        self.devices=devices; self.select.blockSignals(True); self.select.clear()
        for d in devices:self.select.addItem(f'{d.name}  [{d.vid:04X}:{d.pid:04X}]',d.key)
        if not devices:self.select.addItem('Нет подключённых планшетов')
        idx=next((i for i,d in enumerate(devices) if d.key==old),0); self.select.setCurrentIndex(idx); self.select.blockSignals(False); self.choose_device(idx)
    def poll_otd(self):
        if self.device and self.device.width and not self.busy: self.read_otd(auto=True)
    def choose_device(self,index):
        previous=self.device.key if self.device else None
        self.device=self.devices[index] if 0<=index<len(self.devices) else None; d=self.device
        if previous != (d.key if d else None):
            self.active_profile='Не выбран'; self.dirty=False; self.home_profile.setText(self.active_profile)
        if not d:
            self.home_name.setText('Планшет не подключён'); self.home_status.setText('Подключите устройство'); self.device_info.setText('Планшет не подключён'); self.device_detail.setText('VID —  ·  PID —  ·  OTD —'); self.otd_state.setText('Демон OTD: состояние не проверено'); self.apply_btn.setEnabled(False); return
        self.home_name.setText(d.name); self.home_status.setText('Виртуальное устройство' if d.simulation else 'HID-устройство обнаружено'); self.device_info.setText(d.name); self.device_detail.setText(f'{d.manufacturer}  ·  VID {d.vid:04X}  ·  PID {d.pid:04X}  ·  {d.support}'); self.apply_btn.setEnabled(bool(d.width and d.height)); self.otd_state.setText('Проверка OTD…')
        if d.width and d.height:
            self.area=Area(d.width,d.height,d.width/2,d.height/2); self.ratio=self.area.width/self.area.height; self.refresh_fields(); self.read_otd(auto=True)
        else:self.otd_state.setText('Область неизвестна; изменение недоступно.')
    def refresh_fields(self):
        a=self.area; d=self.device; pw=d.width if d and d.width else 152; ph=d.height if d and d.height else 95
        self.block=True
        for k,val in [('width',a.width),('height',a.height),('x',a.x),('y',a.y),('offset_x',a.x-pw/2),('offset_y',a.y-ph/2)]: self.fields[k].setValue(val)
        self.lock.setChecked(a.lock); self.block=False; self.editor.set_data(a,pw,ph); self.home_area.setText(f'{a.width:.1f} × {a.height:.1f} мм'); self.home_profile.setText(self.active_profile)
    def editor_change(self,a): self.area=a; self.dirty=True; self.refresh_fields(); self.feedback.setText('Предпросмотр: изменения не применены.')
    def field_change(self,key,val):
        if self.block:return
        a=copy.copy(self.area); d=self.device; pw=d.width if d and d.width else 152; ph=d.height if d and d.height else 95
        if key=='offset_x':a.x=pw/2+val
        elif key=='offset_y':a.y=ph/2+val
        else:setattr(a,key,val)
        if a.lock and key=='width': a.height=a.width/self.ratio
        if a.lock and key=='height': a.width=a.height*self.ratio
        self.area=a; self.dirty=True; self.refresh_fields(); self.feedback.setText('Предпросмотр: изменения не применены.')
    def toggle_lock(self,on):
        if self.block:return
        self.area.lock=on
        if on and self.area.height>0:self.ratio=self.area.width/self.area.height
        self.dirty=True
    def reset(self):
        d=self.device
        if not d or not d.width or not d.height: self.error('Нет данных о размерах планшета.'); return
        self.area=Area(d.width,d.height,d.width/2,d.height/2); self.ratio=d.width/d.height; self.dirty=True; self.refresh_fields(); self.feedback.setText('Предпросмотр сброшен на полную область. Нажмите «Применить».')
    def read_otd(self,auto=False):
        d=self.device
        if not d or not d.width:return
        key=d.key; self.otd_state.setText('Проверка OTD…'); self.submit(lambda:self.otd.read(d),lambda a,e:self.read_done(key,a,e,auto))
    def read_done(self,key,a,e,auto):
        if not self.device or self.device.key!=key:return
        if e:
            self.otd_state.setText('OTD недоступен: '+str(e));
            if not auto:self.error(e)
            return
        self.otd_state.setText('Симуляция: OTD не используется' if self.simulation else 'Демон OTD доступен; профиль модели найден')
        if not auto or not self.dirty:
            self.area=a; self.ratio=a.width/a.height if a.height else 1; self.dirty=False; self.refresh_fields(); self.feedback.setText('Область прочитана.'+(' Симуляция.' if self.simulation else ''))
    def apply(self):
        d=self.device
        if not d or not d.width: self.error('Подключите поддерживаемый планшет с известными размерами.'); return
        try:self.area.validate(d.width,d.height)
        except (ValueError,TypeError) as e:self.error(e); return
        if self.busy:return
        self.busy=True; self.apply_btn.setEnabled(False); a=copy.copy(self.area); key=d.key; self.feedback.setText('Применение…')
        def work():
            if not any(x.key==key for x in self.detector.scan()): raise RuntimeError('Устройство отключено до применения.')
            return self.otd.apply(d,a)
        self.submit(work,lambda result,e:self.apply_done(key,a,result,e))
    def apply_done(self,key,a,result,e):
        self.busy=False; self.apply_btn.setEnabled(bool(self.device and self.device.width))
        if e:self.feedback.setText('Применение не подтверждено.'); self.error(e); return
        if self.device and self.device.key==key and self.area==a:self.dirty=False
        self.feedback.setText(result)
    def load_profiles(self):
        try:
            self.profiles_data=self.store.all(); self.profile_list.clear(); self.profile_list.addItems([p['name'] for p in self.profiles_data])
        except Exception as e:self.profiles_data=[]; self.error(e)
    def profile_selected(self,i):
        if 0<=i<len(self.profiles_data):
            p=self.profiles_data[i]; a=p['area']; self.profile_desc.setText(f"{p['model']}  ·  {a['width']:.1f} × {a['height']:.1f} мм  ·  центр {a['x']:.1f}, {a['y']:.1f}")
    def selected_profile(self):
        i=self.profile_list.currentRow()
        if not 0<=i<len(self.profiles_data): raise ValueError('Выберите профиль.')
        return self.profiles_data[i]
    def load_profile(self):
        try:
            p=self.selected_profile()
            if not self.device or not self.device.width: raise ValueError('Сначала выберите подключённый планшет с известной областью.')
            if p['model']!=self.device.name: raise ValueError('Профиль предназначен для другой модели планшета.')
            a=Area(**p['area']); a.validate(self.device.width,self.device.height); self.area=a; self.ratio=a.width/a.height; self.active_profile=p['name']; self.dirty=True; self.refresh_fields(); self.goto(1); self.feedback.setText('Профиль загружен в редактор. Нажмите «Применить».')
        except Exception as e:self.error(e)
    def save_profile(self):
        if not self.device or not self.device.width: self.error('Сначала выберите планшет с известными размерами.'); return
        try:self.area.validate(self.device.width,self.device.height)
        except ValueError as e:self.error(e); return
        name,ok=QInputDialog.getText(self,'Сохранить профиль','Название профиля:')
        if not ok:return
        try:
            exists=any(p['name'].casefold()==name.strip().casefold() for p in self.store.all())
            if exists and QMessageBox.question(self,'Заменить профиль?','Профиль уже существует. Заменить его?')!=QMessageBox.StandardButton.Yes:return
            self.store.put(name,self.device.name,self.area,replace=exists); self.active_profile=name.strip(); self.refresh_fields(); self.load_profiles()
        except Exception as e:self.error(e)
    def rename_profile(self):
        try:
            p=self.selected_profile(); name,ok=QInputDialog.getText(self,'Переименовать','Новое название:',text=p['name'])
            if ok:
                self.store.rename(p['name'],name)
                if self.active_profile==p['name']:self.active_profile=name.strip(); self.refresh_fields()
                self.load_profiles()
        except Exception as e:self.error(e)
    def delete_profile(self):
        try:
            p=self.selected_profile()
            if QMessageBox.question(self,'Удалить профиль?',f"Удалить «{p['name']}»?")==QMessageBox.StandardButton.Yes:
                self.store.delete(p['name'])
                if self.active_profile==p['name']:self.active_profile='Не выбран'; self.refresh_fields()
                self.load_profiles()
        except Exception as e:self.error(e)
