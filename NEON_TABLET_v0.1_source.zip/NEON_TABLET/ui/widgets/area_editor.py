from PySide6.QtCore import Qt, QRectF, Signal, QPointF
from PySide6.QtGui import QColor, QPainter, QPen, QBrush, QLinearGradient
from PySide6.QtWidgets import QWidget
from core.models import Area

class AreaEditor(QWidget):
    changed=Signal(object)
    def __init__(self):
        super().__init__(); self.area=Area(152,95,76,47.5); self.pw=152.; self.ph=95.; self.drag=None; self.setMinimumSize(280,190); self.setMouseTracking(True)
    def set_data(self,area,pw,ph):
        self.area=area; self.pw=pw; self.ph=ph; self.update()
    def frame(self):
        w=max(1,self.width()-56); h=max(1,self.height()-56); scale=min(w/self.pw,h/self.ph)
        return QRectF((self.width()-self.pw*scale)/2,(self.height()-self.ph*scale)/2,self.pw*scale,self.ph*scale),scale
    def area_rect(self):
        f,s=self.frame(); a=self.area
        return QRectF(f.left()+(a.x-a.width/2)*s, f.top()+(a.y-a.height/2)*s,a.width*s,a.height*s)
    def paintEvent(self,event):
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing); f,s=self.frame()
        p.setPen(QPen(QColor('#37334d'),1)); p.setBrush(QColor('#171524')); p.drawRoundedRect(f,12,12)
        p.setPen(QPen(QColor('#28243a'),1,Qt.PenStyle.DashLine))
        for i in range(1,4):
            p.drawLine(QPointF(f.left()+f.width()*i/4,f.top()),QPointF(f.left()+f.width()*i/4,f.bottom()))
            p.drawLine(QPointF(f.left(),f.top()+f.height()*i/4),QPointF(f.right(),f.top()+f.height()*i/4))
        r=self.area_rect(); g=QLinearGradient(r.topLeft(),r.bottomRight()); g.setColorAt(0,QColor(139,92,246,85)); g.setColorAt(1,QColor(236,72,153,50)); p.setBrush(QBrush(g)); p.setPen(QPen(QColor('#c084fc'),2)); p.drawRoundedRect(r,4,4)
        p.setBrush(QColor('#f0d8ff')); p.setPen(Qt.PenStyle.NoPen); p.drawEllipse(r.bottomRight(),5,5)
        p.setPen(QColor('#e8d8ff')); p.drawText(r,Qt.AlignmentFlag.AlignCenter,f'{self.area.width:.1f} × {self.area.height:.1f} мм')
        p.setPen(QColor('#827f98')); p.drawText(QRectF(0,self.height()-26,self.width(),20),Qt.AlignmentFlag.AlignCenter,'Перетащите область или нижний правый угол')
    def mousePressEvent(self,e):
        if e.button()!=Qt.MouseButton.LeftButton: return
        r=self.area_rect(); point=e.position(); corner=r.bottomRight()
        if abs(point.x()-corner.x())<14 and abs(point.y()-corner.y())<14: self.drag=('resize',point,self.area)
        elif r.contains(point): self.drag=('move',point,self.area)
    def mouseMoveEvent(self,e):
        if not self.drag: return
        mode,start,orig=self.drag; f,s=self.frame(); dx=(e.position().x()-start.x())/s; dy=(e.position().y()-start.y())/s
        if mode=='move':
            x=max(orig.width/2,min(self.pw-orig.width/2,orig.x+dx)); y=max(orig.height/2,min(self.ph-orig.height/2,orig.y+dy)); a=Area(orig.width,orig.height,x,y,orig.lock)
        else:
            left=orig.x-orig.width/2; top=orig.y-orig.height/2; w=max(1,min(self.pw-left,orig.width+dx)); h=max(1,min(self.ph-top,orig.height+dy))
            if orig.lock:
                ratio=orig.width/orig.height; w=min(w,(self.ph-top)*ratio); h=w/ratio
            a=Area(w,h,left+w/2,top+h/2,orig.lock)
        self.changed.emit(a)
    def mouseReleaseEvent(self,e): self.drag=None
