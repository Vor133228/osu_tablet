STYLE='''
* { font-family: "Segoe UI", sans-serif; font-size: 13px; color: #e8e5f3; }
QMainWindow, QWidget#root, QWidget#page { background: #0e0d16; }
QWidget#sidebar { background: #15131f; border-right: 1px solid #292539; }
QLabel#brand { font-size: 18px; font-weight: 800; color: #f8f4ff; letter-spacing: 1px; }
QLabel#eyebrow { color: #b390ee; font-size: 10px; font-weight: 700; letter-spacing: 1px; }
QLabel#title { font-size: 27px; font-weight: 750; color: #fcfaff; }
QLabel#subtitle, QLabel#muted { color: #9a96aa; }
QLabel#big { font-size: 21px; font-weight: 700; color: #faf7ff; }
QLabel#status { color: #cfb5ff; font-weight: 600; }
QFrame#card { background: #1b1928; border: 1px solid #302b41; border-radius: 15px; }
QFrame#hero { background: qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #302047,stop:0.6 #231b34,stop:1 #211925); border: 1px solid #57406c; border-radius: 16px; }
QPushButton { background: #292538; border: 1px solid #3c354d; border-radius: 9px; padding: 10px 14px; font-weight: 600; }
QPushButton:hover { background: #373048; border-color: #8360a9; }
QPushButton:pressed { background: #4e3665; }
QPushButton:disabled { color: #696675; background: #211f29; border-color: #2b2931; }
QPushButton#primary { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #8758e7,stop:1 #ca55ae); border: none; color: white; }
QPushButton#primary:hover { background: #a675ed; }
QPushButton#nav { text-align: left; padding: 12px 15px; background: transparent; border: none; color: #a29daf; }
QPushButton#nav:checked { background: #30213f; color: #eacbff; border-left: 3px solid #c170e5; }
QLineEdit, QDoubleSpinBox, QComboBox, QListWidget { background: #12111b; border: 1px solid #393348; border-radius: 7px; padding: 7px; selection-background-color: #7545b4; }
QDoubleSpinBox:focus, QLineEdit:focus, QComboBox:focus { border-color: #a873e7; }
QListWidget::item { padding: 12px; border-radius: 5px; }
QListWidget::item:selected { background: #3c2a51; }
QCheckBox { spacing: 8px; }
QScrollArea { border: none; background: transparent; }
QScrollBar:vertical { background: #15131f; width: 9px; }
QScrollBar::handle:vertical { background: #4f425d; border-radius: 4px; }
'''
